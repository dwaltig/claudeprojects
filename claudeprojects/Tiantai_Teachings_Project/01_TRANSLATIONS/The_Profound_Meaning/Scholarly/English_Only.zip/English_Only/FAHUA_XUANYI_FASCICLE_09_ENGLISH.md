# The Profound Meaning of the Lotus Sutra

## Fascicle 9: Entering Real Contemplation, Coarse/Subtle, Essence, and Function

**Scholarly Translation by The Architect**

---

### Part One: Entering Real Contemplation Through the Round Gate

Zhiyi now turns from naming and body to **entering real contemplation** through the **Round Gate**. First he distinguishes the Round Gate; then he explains the Round Contemplation.

#### Distinguishing the Round Gate

The Tripiṭaka Gate “extinguishes real form to reach the true,” which invites contention.  
The Shared Gate “treats illusory form as the true,” pointing to non-contention.  
The Distinct Gate sequentially extinguishes “the form of birth-and-death” and then “the form of Dharma-nature,” passing through the Middle in stages.  
The Round Gate is “birth-and-death as Dharma-nature; Dharma-nature as Middle,” and therefore **non-contentious**.

Both the Distinct and Round Gates reach the Middle, but they differ in **ten ways**, in this order:
1. **Integrated vs. not integrated**: Distinct divides the four gates into separate positions; Round fuses them so “one gate is all gates.”  
2. **Identical to dharmas vs. not identical**: Distinct treats birth‑and‑death and Dharma‑nature as two; Round says **birth‑and‑death is Dharma‑nature**.  
3. **Buddha wisdom vs. non‑Buddha wisdom**: Distinct reaches bodhisattva wisdom; Round directly reveals **Buddha wisdom**.  
4. **Sequential practice vs. non‑sequential practice**: Distinct proceeds step by step; Round says **one practice is all practices**.  
5. **Cutting through defilements vs. not‑cutting**: Distinct emphasizes progressive cutting; Round shows **not‑cutting cutting**.  
6. **Real stages vs. non‑real stages**: Distinct relies on fixed stages; Round treats stages as **provisional and mutually inclusive**.  
7. **Fruit‑vertical vs. fruit‑non‑vertical**: Distinct stacks fruit in sequence; Round says **all fruits are present without vertical separation**.  
8. **Round exposition vs. non‑round exposition**: Distinct speaks from partial angles; Round speaks **from the whole**.  
9. **Interrogation/response**: Distinct relies on external questioning to reveal its direction; Round’s questions and answers already **show the One Vehicle**.  
10. **Parables**: Distinct uses partial parables; Round uses **parables that include all gates at once**.

Zhiyi then uses these ten to show that the Round Gate does **not** fixate on determinate “positions” or “gates.” It speaks of **existence that does not obstruct emptiness** and **emptiness that does not obstruct existence**, so that **one gate is all gates, all gates are one**. This is the mark of the Round Gate.

#### Ten Marks of the Round Gate in the Lotus

Zhiyi demonstrates the Round Gate by ten Lotus passages, matching the CBETA sequence:
1. **“Contemplate all dharmas as empty, as the Reality-Mark.”**  
2. **“Worldly livelihoods do not contradict the Reality-Mark.”**  
3. **“Open, show, awaken, and enter the Buddha’s knowledge and vision.”**  
4. **“Wear the Tathāgata’s robe, sit on his seat, dwell in his room.”**  
5. **“Pass beyond five hundred yojanas.”**  
6. **“Five grades and purity of six roots.”**  
7. **“Ride the jeweled carriage; roam the four directions.”**  
8. **“The Buddha abides in the Great Vehicle; adorns with the power of meditation and wisdom.”**  
9. **“With palms together, wish to hear the complete path.”**  
10. **“The Reality-Mark teaching has already been spoken.”**

The **question/answer** proof is the “Wise Accumulation / Dragon Girl” exchange;  
the **parable** proofs include the Wheel‑King jewel and the great carriage.  
These confirm the ninth and tenth points above.

These ten together show that the Lotus teaches the **Round Gate**.

#### The Four Marks of the Round Gate

The four “marks” are:
1. **Existence** — “Buddha wisdom is subtle and supreme.”  
2. **Emptiness** — all dharmas are empty, always quiescent.  
3. **Both existence and emptiness** — the Buddha‑seed arises from conditions.  
4. **Neither existence nor emptiness** — beyond both, transcending all extremes.

Thus the Lotus reveals **the Round Four Gates**.

#### Ten Contemplations for Entering the Real

By the Round Gate, contemplation enters the **inconceivable realm**: one real reality with four truths that are **empty, provisional, and middle** at once.

The ten contemplations are:
1. **Knowing the object of contemplation**: birth‑and‑death itself is the inconceivable truth.  
2. **Arousing true resolve**: great compassion and great vows arise from the truth.  
3. **Settling the mind**: concentration and wisdom are cultivated together.  
4. **Breaking through dharmas**: cutting through all obstructions like a diamond axe.  
5. **Knowing blockage and openness**: recognizing what obstructs and what frees.  
6. **Knowing the factors of the path**: right mindfulness and the path factors arise from the truth itself.  
7. **Applying antidotes**: counteracting obstacles with the truth as medicine.  
8. **Knowing the stages**: from principle‑Nirvāṇa through name, practice, resemblance, partial realization, and ultimate realization.  
9. **Patient endurance**: steadying the mind against internal and external disturbances.  
10. **No attachment to dharmas**: when attachment arises, it is quickly extinguished; liberation, wisdom, and Dharma‑body manifest together.

These ten are scattered throughout the Lotus. Zhiyi gathers them to show **how the Round Gate enters the real**.

---

### Part Two: Judging Gates as Coarse or Subtle

#### Coarse/Subtle by the Leading and the Led

The “gate” is the **leading**, the “principle” is the **led**.  
Thus four combinations arise: coarse leading/coarse led; subtle leading/coarse led; coarse leading/subtle led; subtle leading/subtle led.

Zhiyi summarizes:
- **Tripiṭaka gates** are coarse in both leading and led.  
- **Shared gates** are subtle in leading but coarse in led.  
- **Distinct gates** are coarse in leading but subtle in led.  
- **Perfect gates** are subtle in both leading and led.

He also maps coarse/subtle across the **five flavors** of teaching.

#### Coarse/Subtle by the Gates Themselves

The four gates can be coarse or subtle depending on **fit with capacities** and **the Four Siddhāntas**.  
A gate is “subtle” when it completes the Four Siddhāntas and the ten contemplations;  
“coarse” when it misses them.

---

### Part Three: Opening Coarse Gates to Reveal the Subtle Gate

Zhiyi explains why a text may “open the coarse to reveal the subtle.”  
When the teaching has already led practitioners to maturity, the Lotus **opens the coarse gates** and reveals the subtle gate as the final, complete meaning.

---

### Part Four: The Reality-Mark as the Body of All Sutras

Zhiyi next shows that **the Reality-Mark** is the body of all sutras, in **five topics**:
1. Different names for the body of this sūtra  
2. Different names for the body of other sūtras  
3. Lateral and primary distinctions  
4. Comparing this and other sūtras  
5. Coarse/subtle and opening coarse to reveal subtle

He lists many names for this sūtra’s body: **Reality-Mark**, **Buddha knowledge and vision**, **great cause‑and‑condition**, **Dharma‑seal**, **great vehicle**, **household business**, **treasure ground**, **secret treasury**, **equal great wisdom**, **neither‑such nor different**, **universal‑manifestation samādhi**, **universal gate**, **root of virtues**, and more.  
These names differ, but the **body is one**.

Other sūtras call the same body by names such as **true and good subtle form**, **ultimate emptiness**, **Tathāgata Treasury**, **Middle**, and so on.  
Thus **the Reality-Mark is the universal seal** of the Great Vehicle.

Lateral/primary distinctions explain how **provisional and definitive** names operate across different teachings and the Five Flavors.  
The Lotus **opens the provisional** and reveals the definitive: **every partial name is opened into the Reality-Mark**.

---

### Part Five: The Body of Practices

Zhiyi distinguishes **practice** in four topics:
1. Same and different practices  
2. Practice according to the sūtras  
3. Coarse/subtle  
4. Opening the coarse

He divides practice into **faith‑practice** and **principle‑practice**, each appearing across the four teachings.  
Horizontal practices (perfections, compassion, etc.) and vertical practices (staged cultivation) both **take the Reality-Mark as body**.  
The Four Modes of Samādhi are likewise **grounded in the Reality-Mark**.  

Thus, even the “small” practices are **opened and revealed as subtle**, because the Lotus brings all practices into the one Reality-Mark.

---

### Part Six: The Body of All Dharmas

Zhiyi concludes the body section by showing that **all dharmas take the Reality-Mark as body**.  
All dharmas are encompassed by the **Four Truths**, and each truth has **innumerable aspects**.

- **Suffering and accumulation** are the complete range of worldly causes and effects.  
- **Path and cessation** are the complete range of supramundane causes and effects.

Thus, **every dharma depends on the Reality-Mark**. The body itself is **wondrous and without difference**, while the dependent dharmas can be **coarse or subtle** according to their function and capacity.  
Opening the coarse and revealing the subtle follows the same logic as before.

---

### Part Seven: Essence/Aim (The Third of Five Chapters)

"**Essence** is the **throat** of practice, the **key pathway** to revealing Substance. Like **pillars holding a house**, like the **main cord of a net**."

"**Lift the cord, and the mesh moves; set the beam, and the rafters stand.**"

### Five Topics on Essence

Explaining Essence has **five topics**:
1. Distinguishing Essence from Substance
2. Directly clarifying Essence
3. Sameness and difference with other sūtras
4. Coarse and subtle
5. Concluding with cause-and-fruit

---

### Distinguishing Essence from Substance

"Some say: 'Essence is Substance, Substance is Essence.' **I don't use this**."

"**Essence's point is cause-and-fruit**; cause-and-fruit are two... If Substance is non-dual, Substance is not Essence."

"**Not-different yet different**: According to non-cause-non-fruit, we discuss cause-and-fruit—hence the distinction between Essence and Substance."

---

### Rejecting Previous Interpretations

| Interpreter | Interpretation | Why Rejected |
|---|---|---|
| Master Huiyuan | One Vehicle as Essence | Too broad—doesn't cover beginning-to-end |
| Master Nāgārjuna | Fruit alone as Essence | Fruit doesn't stand alone; abandons cause and text |
| Master Yin | One-Vehicle realm as Essence (realm + wisdom) | Adds realm but omits fruit |
| Master Guangzhai | One-Vehicle cause-and-fruit as Essence | Splits the text into cause/fruit and flattens both halves |
| Others | Expedient-and-real two wisdoms as Essence | Uses what this sūtra abandons as its aim |
| Others | The title “Wonderful Dharma Lotus” as Essence | Treats the name as the essence |
| Others | Constant-abiding as Essence | If constant is hidden, the essence is not revealed |

---

### The Correct Essence: One-Vehicle Cause-and-Fruit

"**Directly clarifying Essence**: This sūtra from *Introduction* to *Peaceful Practices* [Chapters 1-14]... **establishes disciples' real cause—cause is primary, fruit is secondary**... From *Emerging from Earth* to *Encouragement* [Chapters 15-28]... **reveals the Teacher's real fruit—fruit is primary, cause is secondary**."

"**Combining both cause-and-fruit together makes the sūtra's Essence**—the meaning is in this."

#### The Two Halves of the Sūtra

| Half | Chapters | Content | Focus |
|---|---|---|---|
| **Trace Gate** | 1-14 | Opening expedient, revealing real | **Cause** primary |
| **Fundamental Gate** | 15-28 | Revealing original lifespan | **Fruit** primary |

"Hence the sūtra divides into two texts, discussing Fundamental and Trace... Teacher-and-disciple, expedient-and-real—all are within this."

---

### Sameness and Difference with Other Sūtras

Zhiyi then compares this sūtra’s cause-and-fruit to other sūtras:
- Some sūtras emphasize **cause** (practice) more strongly.  
- Some emphasize **fruit** (realization) more strongly.  
- Some use **cause-and-fruit together**, but only within the Trace Gate.

The Lotus alone presents **both Trace and Fundamental cause-and-fruit**, revealing **disciples’ real cause** and **the Buddha’s real fruit** in a single, complete frame.

### Coarse and Subtle in Essence

When a sūtra presents **partial cause-and-fruit** or relies on expedients, its essence is **coarse**.  
When it reveals **complete cause-and-fruit**, it is **subtle**.

Thus the Lotus is **subtle** because it opens provisional cause-and-fruit into the complete, real cause-and-fruit.

### Concluding with Cause-and-Fruit

Essence is **cause-and-fruit together**:  
cause and fruit are distinct, yet non-dual, and their union is the sūtra’s aim.

---

### Part Eight: Function/Power (The Fourth of Five Chapters)

"**Function** is the Tathāgata's **subtle ability**, this sūtra's **superior power**."

"The Tathāgata takes **expedient-and-real two wisdoms** as subtle ability. This sūtra takes **breaking doubt and generating faith** as superior power."

---

### Distinguishing Function from Essence

"Essence also has function; Function also has essence. **Essence's function is not Function's function; Function's function is not Essence's function.**"

"Essence's function: Cause-and-fruit is essence; cause-and-fruit each have subduing as function..."

"Function has essence: **Compassion** is Function's essence; **breaking doubt, generating faith** is Function's function."

---

### The Unique Function of This Sūtra

"Other sūtras don't purely clarify Buddha's wisdom... don't directly break and abandon Two-Vehicle fruit... **Such power and function no other sūtra has; this sūtra has it completely**."

"**Purely reveals Buddha's subtle wisdom**; doesn't open beings' nine Dharma-Realms knowledge-and-vision—**purely opens beings' Buddha knowledge-and-vision**."

---

### Ten Uses of the Trace Gate

| # | Use | Meaning |
|---|---|---|
| 1 | **Breaking three, revealing one** | Breaking attachment to three vehicles |
| 2 | **Abandoning three, revealing one** | Abandoning expedient teaching |
| 3 | **Opening three, revealing one** | Opening three to show they are one |
| 4 | **Meeting three, revealing one** | Gathering all practices into one |
| 5 | **Abiding in one, revealing one** | Buddha's original intent |
| 6 | **Abiding in three, revealing one** | Using expedient skillfully |
| 7 | **Abiding in neither-three-nor-one, revealing one** | Transcending categories |
| 8 | **Covering three, revealing one** | Preserving expedient for later use |
| 9 | **Abiding in three, using one** | Disciples abiding in expedient |
| 10 | **Abiding in one, using three** | Original vow to teach three |

---

### Ten Uses of the Fundamental Gate

| # | Use | Meaning |
|---|---|---|
| 1 | **Breaking trace, revealing fundamental** | Break attachment to historical Buddha |
| 2 | **Abandoning trace, revealing fundamental** | Abandon the view of recent enlightenment |
| 3 | **Opening trace, revealing fundamental** | Show historical life as part of eternal life |
| 4 | **Meeting trace, revealing fundamental** | Gather all manifestations into the eternal |
| 5 | **Abiding in fundamental, revealing fundamental** | Direct revelation of eternity |
| 6 | **Abiding in trace, revealing fundamental** | Using history to point to eternity |
| 7 | **Abiding in neither-trace-nor-fundamental, revealing fundamental** | Transcending time |
| 8 | **Covering trace, revealing fundamental** | Keeping the historical view provisional |
| 9 | **Abiding in trace, using fundamental** | Historical Buddha using eternal power |
| 10 | **Abiding in fundamental, using trace** | Eternal Buddha appearing in history |

---

### Connection to Four Siddhāntas

"**Concluding with Siddhāntas**: Expedient-real two wisdoms, ten uses different—this is **one voice teaching, each type understanding according to its kind**."

| Siddhānta | Trace Uses | Fundamental Uses |
|---|---|---|
| **World** | Abiding in three, revealing one; abiding in one, using three | Abiding in trace, revealing fundamental; abiding in fundamental, using trace |
| **Person** | Opening three, revealing one; meeting three, returning to one; abiding in three, using one | Opening trace, revealing fundamental; meeting trace, revealing fundamental; abiding in trace, using fundamental |
| **Cure** | Breaking three, abandoning three, covering three | Breaking trace, abandoning trace, covering trace |
| **Ultimate** | Abiding in one, revealing one; abiding in neither-three-nor-one, revealing one | Abiding in fundamental, revealing fundamental; abiding in neither-trace-nor-fundamental, revealing fundamental |

---

### The Unique Power of This Sūtra

"This sūtra's **opening expedient, revealing real**—Four Siddhāntas' great function is **most heroic and fierce**. **Revealing trace, manifesting fundamental**—Four Siddhāntas **eternally different from all other sūtras**."

"The Trace's power and function **already surpasses all teachings**; the Fundamental's ten uses—**no other sūtra has even one**, let alone ten!"

---

## Footnotes

[^1]: The **Essence** chapter establishes that the *Lotus Sūtra*'s aim is **One-Vehicle cause-and-fruit**, divided into the Trace Gate (cause-primary) and Fundamental Gate (fruit-primary).

[^2]: The **Function** chapter identifies the sūtra's unique power as **breaking doubt and generating faith**, accomplished through twenty applications—ten for each gate.
